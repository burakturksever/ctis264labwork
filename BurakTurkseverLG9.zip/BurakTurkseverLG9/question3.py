# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 19:25:28 2020

@author: Burak Turksever 

Question 3
"""

def find(arr):
    chars = ['0', 'E', 'T', 'I', 'A', 'N', 'M', 'S', 'U', 'R', 'W', 'D', 'K',
             'G', 'O', 'H', 'V', 'F', 'Ü', 'L', ' ', 'P', 'J', 'B', 'X', 'C',
             'Y', 'Z', 'Q', 'Ç', 'İ', '5', '4', '$', '3', '?', '_', '.', '-',
             '2', ':', ';', '+', '*', '1', '6', '=', '/', 'Ç', 'Ğ', 'Ö', '7', 
             '8', '9', '0', ',']
    k = len(chars)
    n = len(arr)
    strarr = ''
    j = 0
    i = 0
    while i < n and j < k:
        if arr[i] == ' ':
            strarr = strarr + chars[j]
            j = 0
        else:
            if arr[i] == ".":
                j = 2 * j + 1
            else:
                j = 2 * j + 2
        i = i + 1
    if j>=k:
        print('invalid morse code at', i-1,'. position of the code array')
    print('The given string is : ', strarr)
    
message = ".-- .. - .... .-.- -- -.-- .-.- -... . ... - .-.- .-- .. ... .... . ... "
sos = "... --- ... "
mayday = "-- .- -.-- -.. .- -.-- "
find(message)
find(sos)
find(mayday)