# -*- coding: utf-8 -*-
"""
Created on Mon Apr 20 22:49:57 2020

@author: Burak Turksever

Question 1
"""

import numpy as np

def heapBottomUp(H):
    n = len(H) 
    for i in range(n//2, 0, -1):
        k = i
        v = H[k]
        heap = False
        while not heap and 2 * k <= n-1:
            j = 2 * k
            if j < n:
                if H[j] < H[j+1]:
                    j = j + 1
            if v >= H[j]:
                heap = True
            else:
                H[k] = H[j]
                k = j
        H[k] = v
    return H

H = [0, 2, 9, 7, 6, 5, 8, 10]
print("Beginning Array :", H)
heapBottomUp(H)
print("Array after heapify :", H)
print("Root Node:", H[1])
i = 2
j = 2
n = len(H)-1
while i <= n:
    print(j, ". level nodes:")
    print(H[i:i*2])
    i = i * 2
    j = j + 1

    