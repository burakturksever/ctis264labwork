# -*- coding: utf-8 -*-
"""
Created on Fri Apr 3 02:19:23 2020

@author: Burak Turksever

Question 2
"""

import numpy as np
import time

def merge(A, B, C):
    i=0
    j=0
    k=0
    while i < len(B) and j < len(C):
        if  B[i] < C[j]:
            A[k] = B[i]
            i = i + 1
        else:
            A[k] = C[j]
            j = j + 1
        k = k + 1
    while i < len(B):
        A[k] = B[i]
        k = k + 1
        i = i + 1
    while j < len(C):
        A[k] = C[j]
        k = k + 1
        j = j + 1

def mergeSort(A):
    n = len(A)
    if n > 1:
        mid = n//2
        B = A[:mid]
        C = A[mid:]
        mergeSort(B)
        mergeSort(C)
        merge(A, B, C)
    return A

testArr = np.random.randint(1,1000,10000)
start = time.time()
testArr = mergeSort(testArr)
end = time.time()
print(testArr)
print("Time :", end-start)
