# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 23:02:40 2020

@author: Burak Turksever

Question 3
"""

class treeNode:
    
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data
        
    def insert_node(self, addVal):
        if self.data:
            if addVal < self.data:
                if self.left is None:
                    self.left = treeNode(addVal)
                    print(self.left)
                else:
                    self.left.insert_node(addVal)
                    print(self.left)
            elif addVal > self.data:
                if self.right is None:
                    self.right = treeNode(addVal)
                    print(self.right)
                else:
                    self.right.insert_node(addVal)
                    print(self.right)
        else:
            self.data = data
            
    def inorderTraversal(self, root):
        temp = []
        if root:
            temp = self.inorderTraversal(root.left)
            temp.append(root.data)
            temp = temp + self.inorderTraversal(root.right)
        return temp
    
    def preorderTraversal(self, root):
        temp = []
        if root:
            temp.append(root.data)
            temp = temp + self.preorderTraversal(root.left)
            temp = temp + self.preorderTraversal(root.right)
        return temp
    
    def postorderTraversal(self, root):
        temp = []
        if root:
            temp = self.postorderTraversal(root.left)
            temp = temp + self.postorderTraversal(root.right)
            temp.append(root.data)
        return temp

    def get_right_child(root):
        return root.right
    
    def get_left_child(root):
        return root.left
    
    def set_root_val(value, root):
        root.data = value
    
    def get_root_val(root):
        return root.data
    
    
print('Please enter 10 numbers:')
newTree = treeNode(int(input('Please enter a number:')))
for i in range(1, 9):
    newTree.insert_node(int(input('Please enter a number:')))
print("Inorder traversal", newTree.inorderTraversal(newTree))
print("Preorder traversal", newTree.preorderTraversal(newTree))
print("Postorder traversal", newTree.postorderTraversal(newTree))