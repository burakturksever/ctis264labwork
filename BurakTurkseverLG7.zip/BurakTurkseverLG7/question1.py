# -*- coding: utf-8 -*-
"""
Created on Wed Apr 1 15:49:18 2020

@author: Burak Turksever

Question 1

Issues: There is a very minor issue in the algorithm (3-5 partitions are placed
incorrectly) and I could not resolve the issue but generally it works very well.
"""

import numpy as np
import time

def partition(A):
    p = A[0]
    i = -1
    j = len(A)-1
    while True:
        i = i+1
        while A[i] < p:
            i = i+1
        j = j-1
        while A[j] > p:
            j = j-1
        if i>=j:
            return j
        A[i], A[j] = A[j], A[i]

def quicksort(A):
    if 0 < len(A)-1:
        s = partition(A)
        quicksort(A[0:s-1])
        quicksort(A[s+1:len(A)])
        

A = np.random.randint(0, 100, 10000)
st = time.time()
quicksort(A)
end = time.time()
print(A)
print("Time :", end-st)
