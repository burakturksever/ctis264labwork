# -*- coding: utf-8 -*-
"""
Created on Sat Feb 22 21:17:21 2020

@author: Burak Turksever

Question 3

"""

def fnc_st(arr):
    out = []
    for item in arr:
        if len(item) >= 5:
            out.append(item)
    return out

def fnc_sl(arr):
    out = [item for item in arr if len(item) >= 5 ]
    return out

def init_arr():
    arr = []
    item = input('Enter a word : ')
    while item != 'STOP':
        arr.append(item)
        item = input('Enter a word : ')
    return arr

arr = init_arr()
print('Words with size >= 5', fnc_st(arr))
print('Words with size >= 5 using a single line for loop', fnc_sl(arr))
