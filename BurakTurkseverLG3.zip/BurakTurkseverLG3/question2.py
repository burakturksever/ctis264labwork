# -*- coding: utf-8 -*-
"""
Created on Sat Feb 22 21:08:15 2020

@author: Burak Turksever

Question 2 

"""

import time
import numpy as np


def mult_table():
    start = time.time()
    mtb = []
    for row in range(1,301):
        tbitem = []
        for col in range(1,301):
            tbitem.append(row * col)
        mtb.append(tbitem)
    end = time.time()
    print(mtb)
    return end-start
	#O(n^2), less efficient

def mult_table_np(n):
    start = time.time()
    rng = np.arange(1, n+1)
    rng = rng * rng[:, None]
    end = time.time()
    print(rng)
    return end-start
	#O(1), more efficient

print('Function performed in %10.15f seconds' %mult_table())
print('Function performed in %10.15f seconds using numpy'%mult_table_np(300))