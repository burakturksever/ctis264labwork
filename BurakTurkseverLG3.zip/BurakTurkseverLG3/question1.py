# -*- coding: utf-8 -*-
"""
Created on Sat Feb 22 20:49:15 2020

@author: Burak Turksever

Question 1

"""
import numpy as np


teama = np.array(np.random.randint(0,10,10))
teamb = np.array(np.random.randint(0,10,10))
print('Team A :', teama)
print('Team B :', teamb)
count = 0
ov_five = teama > 5
be_five = teamb <= 5
print('Team A has won', len(teama[ov_five]), 'games')
print('Scores for Team B losses :', teamb[be_five])
print('Average score for all games :', 
      np.average([np.average(teama), np.average(teamb)]))
pd = teama - teamb
print('Point difference for each game :', np.abs(pd))
