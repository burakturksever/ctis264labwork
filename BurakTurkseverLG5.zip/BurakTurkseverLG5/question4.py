# -*- coding: utf-8 -*-
"""
Created on Sun Mar  8 04:04:01 2020

@author: Burak Turksever

Question 4

"""

import numpy as np

def bfs(graph, vertex):
    queue = []
    visited = []
    queue.append(vertex)
    visited.append(vertex)
    while len(queue) != 0:
        currvertex = queue.pop(0)
        for neighbor in graph[currvertex]:
            if neighbor not in visited:
                visited.append(neighbor)
                queue.append(neighbor)
    return visited

def initGraph(vlist, adjMatrix, vcount):
    graph = {}
    temp = []
    for i in range(0,vcount):
        for j in range(0, vcount):
            if adjMatrix[i][j] == 1:
                temp.append(vlist[j])                
        graph.update({vlist[i] : temp})
        temp = []        
    return graph
   
vcount = int(input('Enter the number of vertices : '))
vlist = input('Enter the vertex list for the graph : ')
adjMatrix = []
print('Enter the adjacency matrix : ')
for i in range(0, vcount ** 2):
    adjMatrix.append(int(input()))
adjNp = np.array(adjMatrix)
adjNp.resize(vcount, vcount)
graph = initGraph(vlist, adjNp, vcount)
bfspath = bfs(graph, vlist[0])
print('The graph is : \n', graph)
print('BFS Traversal : \n', bfspath)