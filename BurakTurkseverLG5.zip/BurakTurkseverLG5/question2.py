# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 18:53:45 2020

@author: Burak Turksever

Question 2

"""
import numpy as np
import time

def polinom(arr, x):
    p = 0.0
    for i in range(len(arr)-1,0,-1):
        power = 1
        for j in range(1,i):
            power=power*x
            p = p + arr[i] * power
    return p

arr = np.random.randint(0,100000,1000)
x = 2
st = time.time()
res = polinom(arr, x)
end = time.time()
print(res, '\nTime : ', (end - st))