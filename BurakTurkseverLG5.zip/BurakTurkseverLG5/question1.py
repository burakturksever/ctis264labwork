# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 18:40:25 2020

@author: Burak Turksever

Question 1

"""
import numpy as np
import time

def polinom(arr, x):
    p = arr[0]
    power = 1
    for i in range(1, len(arr)-1):
        power = power * x
        p = p + arr[i] * power
    return power

arr = np.random.randint(0, 100000, 1000)
x = int(input('Enter the value of X : '))
st = time.time()
pw = polinom(arr, x)
end = time.time()
print(pw, '\nTime : ', (end-st))