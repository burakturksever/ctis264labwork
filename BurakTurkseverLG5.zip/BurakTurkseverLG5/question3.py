# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 19:15:10 2020

@author: Burak Turksever

Question 3

"""
import numpy as np

def dfs(graph, vertex, path):
    for neighbor in graph.get(vertex):
        path.append(vertex)
        if neighbor not in path:
            path = dfs(graph, neighbor, path)
    return path

def initGraph(vlist, adjMatrix, vcount):
    graph = {}
    temp = []
    for i in range(0,vcount):
        for j in range(0, vcount):
            if adjMatrix[i][j] == 1:
                temp.append(vlist[j])                
        graph.update({vlist[i] : temp})
        temp = []        
    return graph
   
vcount = int(input('Enter the number of vertices : '))
vlist = input('Enter the vertex list for the graph : ')
adjMatrix = []
print('Enter the adjacency matrix : ')
for i in range(0, vcount ** 2):
    adjMatrix.append(int(input()))
adjNp = np.array(adjMatrix)
adjNp.resize(vcount, vcount)
graph = initGraph(vlist, adjNp, vcount)
dfspath = dfs(graph, vlist[0], [])
dfspath = list(dict.fromkeys(dfspath))
print('The graph is : \n', graph)
print('DFS Traversal : \n', dfspath)
