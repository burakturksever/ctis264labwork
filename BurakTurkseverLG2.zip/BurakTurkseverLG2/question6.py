# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 18:24:09 2020

@author: Burak Turksever

Question 6

"""

import time 
import math

def sieve(num):
    arr=[]
    i=0
    for i in range(num):
        arr.append(i)
        i+=1
    i=0
    for i in range(2, math.floor(math.sqrt(num))+1):
        if arr[i] != 0:
            j = i+i
            while j <= num-1:
                arr[j]=0
                j=j+i
    k=0
    size=len(arr)
    out=[]
    while k < size:
        if arr[k]!=0 and arr[k]!=1:
            out.append(arr[k])
        k+=1
    return out

def primeFactors(num):
    arr=sieve(num)
    i=0
    fac=[]
    while i < len(arr):
        while num%arr[i] == 0:
            fac.append(arr[i])
            num=num/arr[i]
        i+=1
    return fac
    

def checkCommon(arr1,arr2):
    len1=len(arr1)
    len2=len(arr2)
    i=0
    out=[]
    if len1<=len2:
        for i in range(len1):
            if arr1[i]==arr2[i]:
                out.append(arr1[i])
    else:
        for i in range(len2):
            if arr2[i]==arr1[i]:
                out.append(arr2[i])
    return out

def gcd(arr):
    mults=1
    for item in arr:
        mults*=item
    return mults

num1 = int(input('Input a non-negative integer please (>=2):'))
num2 = int(input('Input another non-negative integer please (>=2):'))
print()
start = time.time()
arr1 = primeFactors(num1)
arr2 = primeFactors(num2)
end = time.time()
print('Prime factors of n :', arr1)
print('Prime factors of m :', arr2)
comm=checkCommon(arr1, arr2)
mults=gcd(comm)
print('Common prime factors are :', comm)
print('Greatest common divisor :', mults)
print('Execution time : ', end-start, 'seconds')
