# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 18:11:32 2020

@author: Burak Turksever

Question 5

"""
import time


def sumFunc():
    start_time=time.time()
    sum=0
    for i in range(100001):
        sum+=i
    print('Execution time : ', (time.time()-start_time), 'seconds')
    print('Result : ', sum)

sumFunc()
sumFunc()
sumFunc()
sumFunc()
sumFunc()

start_time=time.time()
result = (100000*(100000+1))/2
exec_time = time.time()-start_time
print('Using the formula: \nExecution time : ', exec_time,'seconds' ,'\nResult:', result)