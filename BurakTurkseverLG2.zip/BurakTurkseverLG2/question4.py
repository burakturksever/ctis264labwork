# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 17:48:35 2020

@author: Burak Turksever

Question 4

"""

import random 

rand=random.randint(1,900)

name=input('Please enter your name and surname: ')
print(name)
# in order to also include 6 to get the same output as the guide,
# we require to write name[3:7], by doing so we ensure that
# 4 characters of the original string (3rd,4th,5th & 6th) are
# included in the password 
passw=name[3:7]
print('Slicing the name (3,6) : ', passw)
print('Random number (1-900) : ', rand)
passw=passw+str(rand)
print('Generated password : ',passw)