# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 17:04:55 2020

@author: Burak Turksever

Question 3

"""

carDict = {'Honda CR-V': 125000, 'Volkswagen Passat': 135000, 
           'Toyota Yaris': 55000, 'Volkswagen Toureg': 255000, 
           'Honda Civic': 95000}
print('Original Dictionary:\n',carDict)
print('Prices over 100000:')
for item in carDict:
    if carDict.get(item) > 100000:
        print(item)
for item in carDict:
    if carDict.get(item) < 100000:
        item={item: 99000}
        carDict.update(item)
print('Updated Dictionary: \n', carDict)
