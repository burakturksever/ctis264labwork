# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 16:31:19 2020

@author: zer0
"""

courses = [('CS 125', 3),('HIST 200',4),('PHIL 243',6),('POLS 304',3),('ENG 101',3)]
sumOfCredits=0
for item in courses:
    itemStr=str(item[0])
    num=int(itemStr[itemStr.find(' '):])
    if num < 200:
        print(itemStr)
        sumOfCredits+=item[1]
print('Total credits for first year courses : ', sumOfCredits)
    