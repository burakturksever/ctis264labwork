# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 16:12:04 2020

@author: Burak Turksever

Question 1

"""
arr = []
i=0
sum=0
while i < 5:
    arr.append(int(input('Enter a number : ')))
    sum+=arr[i]
    i+=1
avg=sum/5
print('The average is', avg)
arr.sort()
print('Sorted format of the list:', arr)
arr.reverse()
print('Reverse format of the list:', arr)
for j in arr:
    if j < avg:
        arr.remove(j)
        break
print('Final format of the list:', arr)