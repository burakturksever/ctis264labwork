# -*- coding: utf-8 -*-
"""
Created on Sun Mar 29 01:22:19 2020

@author: Burak Turksever

Question 1
"""

import numpy as np
import time

def insertionSort(A):
    for i in range(1, len(A)):
        v = A[i]
        j = i - 1
        while j >= 0 and A[j] > v:
            A[j+1] = A[j]
            j = j - 1
            A[j+1] = v
    return A

arr = []
for i in range(1,5):
    arr.append(np.random.randint(0,100000,1000))
    print('Some part of array', i)
    st = time.time()
    arr[i-1] = insertionSort(arr[i-1])
    end = time.time()
    randItems = np.random.randint(0,900)
    print('Some part of the array', arr[i-1][randItems:randItems+10])
    print('Time :', end - st)    
            