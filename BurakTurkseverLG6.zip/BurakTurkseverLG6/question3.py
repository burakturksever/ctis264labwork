# -*- coding: utf-8 -*-
"""
Created on Sun Mar 29 01:36:47 2020

@author: Burak Turksever

Question 3
"""
   

def lomutoPartition(A):
    p = A[0]
    s = 0
    for i in range(1, len(A)-1):
        if A[i] < p:
            s = s + 1
            A[s], A[i] = A[i], A[s]
    A[0], A[s] = A[s], A[0]
    return s

arr = [10,7,8,9,1,5]

index = int(input('Enter the item number that will be searched as index value : '))
lomutoPartition(arr)
print('Partially sorted array :' , arr)
print('Selected item ('+ str(index) +') of the array is:', arr[index])