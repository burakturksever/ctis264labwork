# -*- coding: utf-8 -*-
"""
Created on Sun Mar 29 01:34:34 2020

@author: Burak Turksever

Question 2
"""

from collections import defaultdict

class Graph:
    def __init__(self, vCount):
        self.graph = defaultdict(list)
        self.V = vCount
        
    def addEdge(self, a, b):
        self.graph[a].append(b)
    
    def topologicalSortUtil(self, v, visited, stack):
        visited[v] = True
        
        for i in self.graph[v]:
            if visited[i] == False:
                self.topologicalSortUtil(i, visited, stack)
        stack.insert(0, v)
        
    def topologicalSort(self): 
        visited = [False] * self.V 
        stack = []        
        for i in range(self.V): 
            if visited[i] == False: 
                self.topologicalSortUtil(i, visited, stack)  
        print(stack) 
            
testGraph = Graph(6)
testGraph.addEdge(5,2)
testGraph.addEdge(5,0)
testGraph.addEdge(4,0)
testGraph.addEdge(4,1)
testGraph.addEdge(2,3)
testGraph.addEdge(3,1)


print('Topologically sorted graph for the given edges:')
testGraph.topologicalSort()