# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 22:01:37 2020

@author: Burak Turksever

Question 8

"""

def findGCDWithEuclid(x,y):
    while y != 0:
        r = x % y
        x = y
        y = r
    return x

x = int(input("Enter first number for GCD : "))
y = int(input("Enter second number for GCD : "))
print("GCD obtained from Euclid's Algorithm : ", findGCDWithEuclid(x,y))