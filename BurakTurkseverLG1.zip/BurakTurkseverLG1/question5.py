# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 20:35:01 2020

@author: Burak Turksever

Question 5 Answer

"""

name = input("Enter your name : ")

print("Your name contains", len(name), "characters")
print("Your name contains 'a'", name.count('a'), "times")
print("Position of blank from start:", name.find(" "))
print("Your surname is", name[name.find(" "):])
print("The position of your surname from the beginning:", (name.rfind(" ") + 1))
print("Your name in lowercase:", name.lower())
print("Your name in uppercase:", name.upper())
print("Length of your name is", name.find(" "), "and your surname is", 
      ((len(name) - name.rfind(" "))-1))
print("After replacing all 'e' to 'w'", name.replace('e', 'w'))