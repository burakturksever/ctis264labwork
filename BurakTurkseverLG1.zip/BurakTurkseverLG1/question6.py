# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 20:52:10 2020

@author: Burak Turksever

Question 6

"""

def sumOfOdds():
    userIn = int(input("Enter an integer value except 0: "))
    sumOfOdds = 0;
    while userIn != 0:
        if userIn%2 != 0:
            sumOfOdds = sumOfOdds + userIn
        userIn = int(input("Enter an integer value except 0: "))
    return sumOfOdds

a = sumOfOdds()        
print(a)