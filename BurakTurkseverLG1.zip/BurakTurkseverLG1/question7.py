# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 20:58:24 2020

@author: Burak Turksever

Question 7

"""

def findGCDWithCIC(x, y):
    t =  min(x, y)
    while t != 0:
        if x % t == 0 :
            if y % t == 0:
                return t
        t = t - 1
    return t
    

x = int(input("Please enter a non-negative integer : "))
y = int(input("Please enter another non-negative integer : "))
res = findGCDWithCIC(x,y)
print("GCD from consecutive integer checking algorithm:", res)
        
