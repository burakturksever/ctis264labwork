# -*- coding: utf-8 -*-
"""
Created on Sun Mar  1 18:37:26 2020

@author: Burak Turksever

Question 3

"""

import numpy as np
import time

def BFStringMatch(A, B):
    for i in range(0, len(A)-len(B)):
        j = 0
        while j < len(B) and B[j] == A[i+j]:
            j = j+1
        if j == len(B):
            return i
    return -1
st=time.time()
res = BFStringMatch("NOBODY_NOTICED_HIM", "NOT")
end=time.time()
print("First index of NOT in the text is", res, "\nTime:", end-st)
