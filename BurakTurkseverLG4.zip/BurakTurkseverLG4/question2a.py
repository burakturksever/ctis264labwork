# -*- coding: utf-8 -*-
"""
Created on Sun Mar  1 17:31:56 2020

@author: Burak Turksever

Question 2a

"""

import numpy as np
import time

def swap(arr, p1, p2):
    arr[p1], arr[p2] = arr[p2], arr[p1]
    return arr

A=np.random.randint(0,100, size=1000)

st=time.time()
for i in range(0, len(A)-1):
    for j in range(0, len(A)-1-i):
        if A[j+1] < A[j]:
            A = swap(A, j, j+1)
end=time.time()

print(A, "\nTime:", end-st)