# -*- coding: utf-8 -*-
"""
Created on Sun Mar  1 18:17:40 2020

@author: Burak Turksever

Question 2b

"""

import numpy as np
import time

def swap(arr, p1,p2):
    arr[p1], arr[p2] = arr[p2], arr[p1]
    return arr

A = np.random.randint(0, 100, size=1000)
i = 0
flag = True
st=time.time()
while i < len(A)-1 and flag == True:
    flag=False
    for j in range(0, len(A)-1-i):
        if A[j+1] < A[j]:
            A = swap(A, j, j+1)
            flag=True
    i+=1
end=time.time()

print(A, "\nTime:", end-st)
