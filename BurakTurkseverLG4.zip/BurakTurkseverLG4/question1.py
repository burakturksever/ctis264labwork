# -*- coding: utf-8 -*-
"""
Created on Sun Mar  1 17:22:48 2020

@author: Burak Turksever

Question 1

"""
import numpy as np
import time


def swap(arr, p1, p2):
    arr[p1], arr[p2]=arr[p2], arr[p1]
    return arr
    
    
A = np.random.randint(0,100, size=1000)

st = time.time()
for i in range(0, len(A)-2):
    m = i
    for j in range(i+1, len(A)):
        if A[j] < A[m]:
            m=j
        A = swap(A, i, m)
end = time.time()

print(A, "\nTime:", end-st)