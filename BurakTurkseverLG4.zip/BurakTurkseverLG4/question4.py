# -*- coding: utf-8 -*-
"""
Created on Sun Mar  1 20:28:50 2020

@author: Burak Turksever

Question 4

"""

import time

def seqSearch(A, key):
    i = 0
    while i < len(A) and A[i] != key:
        i = i + 1
    if i < len(A):
        return i
    else:
        return -1

test = [1, 2, 32, 8, 17, 19, 42, 13, 0]
key = int(input("Enter a search value:"))
st = time.time()
res = seqSearch(test, key)
end = time.time()
print("Value found at index: ", res, "\nTime:", end-st)